#pragma once

// Projeto configurado para Wokwi no VS Code.
// O ESP32 virtual usa a rede simulada e encaminha MQTT para o Mosquitto local.
#define WOKWI_SIMULATION 1
#define WIFI_SSID "Wokwi-GUEST"
#define WIFI_PASSWORD ""
#define WIFI_CHANNEL 6

// host.wokwi.internal requer o Wokwi Private IoT Gateway ativo no VS Code.
#define MQTT_BROKER_HOST "host.wokwi.internal"
#define MQTT_BROKER_PORT 1883
#define MQTT_USERNAME "citizentech"
#define MQTT_PASSWORD "TROQUE_POR_UMA_SENHA_LOCAL"
#define MQTT_TOPIC "citizentech-agro/esp32/readings"
