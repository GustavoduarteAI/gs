# Copie este arquivo para settings.py e use os mesmos dados do secrets.h.
# O receptor e o broker estão no mesmo computador.
MQTT_BROKER = "127.0.0.1"
MQTT_PORT = 1883
MQTT_USERNAME = "citizentech"
MQTT_PASSWORD = "TROQUE_POR_UMA_SENHA_LOCAL"
MQTT_TOPIC = "citizentech-agro/esp32/readings"
HTTP_HOST = "127.0.0.1"
HTTP_PORT = 8080
