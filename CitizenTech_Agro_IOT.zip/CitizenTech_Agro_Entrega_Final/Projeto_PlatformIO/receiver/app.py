from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

import paho.mqtt.client as mqtt

try:
    from settings import (
        HTTP_HOST, HTTP_PORT, MQTT_BROKER, MQTT_PASSWORD,
        MQTT_PORT, MQTT_TOPIC, MQTT_USERNAME,
    )
except ImportError as exc:
    raise SystemExit(
        "Crie receiver/settings.py a partir de receiver/settings.example.py e preencha os dados."
    ) from exc

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "data" / "readings.sqlite3"
HTML_PATH = ROOT / "dashboard.html"
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
db_lock = threading.Lock()
db = sqlite3.connect(DB_PATH, check_same_thread=False)
db.row_factory = sqlite3.Row
db.execute("""
    CREATE TABLE IF NOT EXISTS sensor_readings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id TEXT NOT NULL,
        message_number INTEGER NOT NULL,
        soil_raw INTEGER NOT NULL CHECK (soil_raw BETWEEN 0 AND 4095),
        soil_moisture_pct REAL NOT NULL CHECK (soil_moisture_pct BETWEEN 0 AND 100),
        air_temperature_c REAL NOT NULL CHECK (air_temperature_c BETWEEN -40 AND 80),
        air_humidity_pct REAL NOT NULL CHECK (air_humidity_pct BETWEEN 0 AND 100),
        uptime_ms INTEGER NOT NULL,
        received_at TEXT NOT NULL
    )
""")
db.commit()
connected = threading.Event()
last_mqtt_error = ""


def process_payload(payload: bytes) -> None:
    """Validate and save one MQTT message in the local SQLite database."""
    data = json.loads(payload.decode("utf-8"))
    if not isinstance(data, dict):
        raise ValueError("A mensagem deve ser um objeto JSON.")
    device_id = data.get("deviceId")
    message_number = data.get("messageNumber")
    soil_raw = data.get("soilRaw")
    soil_moisture = data.get("soilMoisturePct")
    temperature = data.get("airTemperatureC")
    humidity = data.get("airHumidityPct")
    uptime = data.get("uptimeMs")

    if device_id != "esp32-horta-01":
        raise ValueError("Identificador do dispositivo não reconhecido.")
    if isinstance(message_number, bool) or not isinstance(message_number, int) or message_number < 0:
        raise ValueError("Número da mensagem inválido.")
    if isinstance(soil_raw, bool) or not isinstance(soil_raw, int) or not 0 <= soil_raw <= 4095:
        raise ValueError("Valor ADC do sensor de solo inválido.")
    for name, value, minimum, maximum in (
        ("soilMoisturePct", soil_moisture, 0, 100),
        ("airTemperatureC", temperature, -40, 80),
        ("airHumidityPct", humidity, 0, 100),
    ):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not minimum <= value <= maximum:
            raise ValueError(f"{name} fora da faixa permitida.")
    if isinstance(uptime, bool) or not isinstance(uptime, int) or uptime < 0:
        raise ValueError("uptimeMs inválido.")

    received_at = datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
    with db_lock:
        db.execute("""
            INSERT INTO sensor_readings
            (device_id, message_number, soil_raw, soil_moisture_pct,
             air_temperature_c, air_humidity_pct, uptime_ms, received_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (device_id, message_number, soil_raw, soil_moisture,
              temperature, humidity, uptime, received_at))
        db.commit()
    print(f"MQTT recebido e salvo no SQLite: mensagem {message_number}, solo {soil_moisture}%.")


def reading_to_view(row: sqlite3.Row | None) -> dict | None:
    if row is None:
        return None
    reading = dict(row)
    advice = []
    if reading["soil_moisture_pct"] < 35:
        advice.append("Solo seco: verifique se o canteiro precisa de irrigação.")
    elif reading["soil_moisture_pct"] > 75:
        advice.append("Solo úmido: verifique a drenagem do canteiro.")
    if reading["air_temperature_c"] > 32:
        advice.append("Temperatura elevada: observe a exposição ao sol nos horários mais quentes.")
    if not advice:
        advice.append("Valores dentro das faixas didáticas; continue acompanhando o canteiro.")
    reading["condition"] = "Atenção" if any(
        phrase in " ".join(advice) for phrase in ("Solo seco", "Solo úmido", "Temperatura elevada")
    ) else "Estável"
    reading["advice"] = advice
    return reading


def latest_readings(limit: int = 20) -> list[dict]:
    with db_lock:
        rows = db.execute(
            "SELECT * FROM sensor_readings ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    return [reading_to_view(row) for row in rows]


class RequestHandler(BaseHTTPRequestHandler):
    def send_json(self, status: int, value: dict) -> None:
        payload = json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/":
            body = HTML_PATH.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(body)
        elif path == "/api/status":
            self.send_json(200, {"mqtt": "conectado" if connected.is_set() else "aguardando", "error": last_mqtt_error})
        elif path == "/api/latest":
            readings = latest_readings()
            self.send_json(200, {"latest": readings[0] if readings else None, "history": readings})
        else:
            self.send_json(404, {"error": "not_found"})

    def log_message(self, format: str, *args) -> None:
        return


def on_connect(client, userdata, flags, reason_code, properties) -> None:
    global last_mqtt_error
    if reason_code == 0:
        connected.set()
        last_mqtt_error = ""
        client.subscribe(MQTT_TOPIC, qos=1)
        print(f"Inscrito no tópico MQTT: {MQTT_TOPIC}")
    else:
        connected.clear()
        last_mqtt_error = f"Conexão MQTT recusada: {reason_code}"
        print(last_mqtt_error)


def on_disconnect(client, userdata, disconnect_flags, reason_code, properties) -> None:
    connected.clear()
    if reason_code != 0:
        print(f"Conexão MQTT interrompida: {reason_code}")


def on_message(client, userdata, message) -> None:
    global last_mqtt_error
    try:
        if len(message.payload) > 1024:
            raise ValueError("Payload excede 1 KB.")
        process_payload(message.payload)
        last_mqtt_error = ""
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError, sqlite3.Error) as exc:
        last_mqtt_error = str(exc)
        print(f"Mensagem descartada: {last_mqtt_error}")


def main() -> None:
    client = mqtt.Client(
        mqtt.CallbackAPIVersion.VERSION2,
        client_id="citizentech-tela-receptora",
        protocol=mqtt.MQTTv311,
    )
    client.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)
    client.on_connect = on_connect
    client.on_disconnect = on_disconnect
    client.on_message = on_message
    client.reconnect_delay_set(min_delay=1, max_delay=15)
    client.connect_async(MQTT_BROKER, MQTT_PORT, keepalive=30)
    client.loop_start()

    server = ThreadingHTTPServer((HTTP_HOST, HTTP_PORT), RequestHandler)
    print(f"Tela local: http://{HTTP_HOST}:{HTTP_PORT}")
    print(f"Banco SQLite: {DB_PATH}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nEncerrando receptor.")
    finally:
        server.shutdown()
        server.server_close()
        client.disconnect()
        client.loop_stop()
        db.close()


if __name__ == "__main__":
    main()
