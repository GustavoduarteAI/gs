# CitizenTech Agro IoT — ESP32 simulado no Wokwi

Projeto independente do frontend React. O ESP32 simulado lê um DHT22 e um potenciômetro que representa a leitura analógica do sensor de umidade do solo, publica dados por MQTT e um receptor local exibe e grava as mensagens em SQLite.

> **Escopo da demonstração:** não exige ESP32 nem sensores físicos. DHT22 e potenciômetro são componentes simulados no Wokwi. O potenciômetro representa o sensor de solo; não é uma medição real de umidade.

## Fluxo

```text
DHT22 + potenciômetro (simulados) → ESP32 Wokwi → MQTT local
                                                ↓
                                      receptor Python + SQLite
                                                ↓
                                      painel no navegador
```

O tópico MQTT é `citizentech-agro/esp32/readings`. O painel mostra temperatura, umidade do ar, leitura analógica, umidade de solo estimada e histórico recebido.

## O que instalar

- Visual Studio Code;
- extensões **PlatformIO IDE** e **Wokwi** para VS Code;
- Python 3;
- Eclipse Mosquitto.

O Wokwi executa o firmware compilado pelo PlatformIO. O projeto já traz `wokwi.toml` e `diagram.json`; antes de iniciar a simulação, compile com **PlatformIO: Build**. Para conectar o ESP32 virtual ao Mosquitto local, é necessário ativar o **Private IoT Gateway**. O gateway público padrão do Wokwi acessa a internet, mas não serviços locais; o gateway privado pode depender do plano Wokwi contratado.

## 1. Iniciar o broker MQTT no Windows

1. Crie a pasta do broker:

   ```powershell
   New-Item -ItemType Directory -Force C:\citizentech-iot\data
   ```

2. Copie `mosquitto.conf.example` para `C:\citizentech-iot\mosquitto.conf`.
3. No PowerShell, crie um usuário e senha locais para a demonstração:

   ```powershell
   Set-Location 'C:\Program Files\mosquitto'
   .\mosquitto_passwd.exe -c C:\citizentech-iot\passwd citizentech
   ```

4. Crie a ACL para permitir acesso apenas ao tópico do projeto:

   ```powershell
   @('user citizentech', 'topic readwrite citizentech-agro/esp32/readings') | Set-Content -Encoding ascii C:\citizentech-iot\aclfile
   ```

5. Inicie o Mosquitto e deixe o terminal aberto:

   ```powershell
   .\mosquitto.exe -c C:\citizentech-iot\mosquitto.conf -v
   ```

Se o firewall bloquear a conexão pelo gateway local, permita TCP 1883 somente no perfil de rede privada. Não exponha essa porta na internet.

## 2. Iniciar o receptor e o painel

Abra um segundo PowerShell na pasta do projeto e execute:

```powershell
Copy-Item receiver\settings.example.py receiver\settings.py
```

Edite `receiver/settings.py` e informe a mesma senha criada para o Mosquitto. O endereço do broker deve continuar `127.0.0.1`, pois o receptor roda no mesmo computador que o Mosquitto.

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install -r receiver\requirements.txt
py receiver\app.py
```

Abra [http://127.0.0.1:8080](http://127.0.0.1:8080). A tela fica em “Aguardando MQTT” até chegar a primeira mensagem. O histórico local é gravado em `receiver/data/readings.sqlite3`.

## 3. Executar a simulação no VS Code

1. Abra no VS Code a pasta raiz do projeto, onde estão `platformio.ini`, `wokwi.toml` e `diagram.json`.
2. Instale a extensão Wokwi para VS Code. Caso solicitado, faça login e ative a licença da extensão.
3. Abra `include/secrets.example.h`, copie o conteúdo para `include/secrets.h` e substitua `TROQUE_POR_UMA_SENHA_LOCAL` pela senha MQTT local. O arquivo `secrets.h` é ignorado pelo Git.
4. No PlatformIO, clique em **Build** e aguarde a compilação.
5. Ative **Wokwi Private IoT Gateway** no VS Code para permitir ao simulador alcançar o broker no computador. Se essa opção não estiver disponível na sua conta/plano, o ESP32 virtual não conseguirá acessar o Mosquitto local; o gateway público não dá acesso ao PC. O firmware usa `host.wokwi.internal` e a rede simulada `Wokwi-GUEST`.
6. Pressione `F1` e escolha **Wokwi: Start Simulator**. Deixe a janela do simulador visível para acompanhar a execução.
7. Abra o Monitor Serial em 115200 baud. A saída esperada inclui `Wi-Fi conectado` e `MQTT publicado` a cada cinco segundos.

## 4. Testar os dois cenários

No `diagram.json`, o potenciômetro está ligado ao GPIO 34. Clique no controle para selecioná-lo; use **Home** para o mínimo, **End** para o máximo e as setas para ajustar aos poucos. Acompanhe a porcentagem no painel:

1. **Representar solo seco:** gire até a leitura indicar umidade abaixo de 35%. O painel deve mostrar a orientação para verificar a irrigação.
2. **Representar solo úmido:** gire para o extremo oposto até a umidade ultrapassar 75%. O painel deve atualizar a leitura e indicar que se verifique a drenagem.

Os valores analógicos iniciais de seco/úmido (`SOIL_DRY_RAW = 3200` e `SOIL_WET_RAW = 1400`) são limites demonstrativos do potenciômetro. O DHT22 simulado inicia em 26 °C e 58% de umidade do ar; seus valores podem ser ajustados nos atributos do componente no `diagram.json` ou no editor do Wokwi.

## Evidências para a apresentação

Registre capturas de tela que mostrem:

- circuito Wokwi com os componentes simulados;
- Monitor Serial com mensagens `MQTT publicado`;
- painel em cada cenário (abaixo de 35% e acima de 75%);
- recebimento e histórico no painel.

O receptor também grava cada mensagem em SQLite. Na apresentação, informe que as entradas vêm do Wokwi e que a porcentagem de solo é uma representação simulada, não resultado de teste em campo.

## Segurança e limitações

- O broker exige usuário e senha e a ACL restringe o acesso ao tópico da demonstração.
- Mantenha broker e simulador na configuração local de demonstração; não abra a porta 1883 para a internet nem use senhas pessoais.
- A simulação testa firmware, formato MQTT, recepção, histórico e comportamento do painel; não comprova precisão de sensores físicos, calibração agronômica, alcance de rádio ou funcionamento em campo.
- Os avisos de irrigação/drenagem são regras didáticas, não recomendações agronômicas profissionais.
- Não há integração com frontend React nem envio dos dados a serviços externos.

## ODS relacionados

- **ODS 2 — Fome zero e agricultura sustentável:** demonstração de monitoramento de uma horta comunitária.
- **ODS 6 — Água potável e saneamento:** leitura simulada para discutir irrigação consciente.
- **ODS 11 — Cidades e comunidades sustentáveis:** exemplo de tecnologia para iniciativas locais.

## Arquivos principais

- `platformio.ini` — placa e bibliotecas PlatformIO.
- `src/main.cpp` — leitura dos componentes, conexão Wi-Fi e publicação MQTT.
- `diagram.json` — placa e circuito Wokwi.
- `wokwi.toml` — caminhos do firmware PlatformIO para o simulador.
- `receiver/app.py` — assinatura MQTT, validação, SQLite e servidor local.
- `receiver/dashboard.html` — painel de recebimento.
- `mosquitto.conf.example` — configuração do broker local.

## Fontes oficiais

- [Simular projetos PlatformIO no Wokwi](https://docs.wokwi.com/vscode/platformio)
- [Rede Wi-Fi e gateway do ESP32 no Wokwi](https://docs.wokwi.com/guides/esp32-wifi)
- [Potenciômetro simulado no Wokwi](https://docs.wokwi.com/parts/wokwi-potentiometer)
- [Planos do Wokwi e gateway privado](https://wokwi.com/pricing)
- [Wokwi para VS Code](https://docs.wokwi.com/vscode/getting-started)
- [Autenticação do Mosquitto](https://mosquitto.org/documentation/authentication-methods/)
