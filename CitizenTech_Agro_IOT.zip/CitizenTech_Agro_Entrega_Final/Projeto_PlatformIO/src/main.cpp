#include <Arduino.h>
#include <DHT.h>
#include <PubSubClient.h>
#include <WiFi.h>

#include "secrets.h"

namespace {
constexpr uint8_t DHT_PIN = 4;
constexpr uint8_t SOIL_SENSOR_PIN = 34; // Potenciômetro Wokwi representa sensor capacitivo.
constexpr uint8_t DHT_TYPE = DHT22;
constexpr uint16_t SAMPLE_INTERVAL_MS = 5000;
constexpr uint16_t SOIL_DRY_RAW = 3200; // Calibrar no sensor real.
constexpr uint16_t SOIL_WET_RAW = 1400; // Calibrar no sensor real.

const char *DEVICE_ID = "esp32-horta-01";
DHT dht(DHT_PIN, DHT_TYPE);
WiFiClient network;
PubSubClient mqtt(network);
uint32_t lastSampleAt = 0;
uint32_t messageNumber = 0;

uint16_t readSoilRaw() {
  uint32_t sum = 0;
  constexpr uint8_t samples = 10;
  for (uint8_t i = 0; i < samples; ++i) {
    sum += analogRead(SOIL_SENSOR_PIN);
    delay(10);
  }
  return static_cast<uint16_t>(sum / samples);
}

uint8_t soilMoisturePercent(uint16_t raw) {
  const long mapped = map(raw, SOIL_DRY_RAW, SOIL_WET_RAW, 0, 100);
  return static_cast<uint8_t>(constrain(mapped, 0, 100));
}

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  Serial.printf("Conectando ao Wi-Fi %s", WIFI_SSID);
  WiFi.mode(WIFI_STA);
#if WOKWI_SIMULATION
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD, WIFI_CHANNEL);
#else
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
#endif
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print('.');
  }
  Serial.printf("\nWi-Fi conectado. IP do ESP32: %s\n", WiFi.localIP().toString().c_str());
}

void connectMqtt() {
  while (!mqtt.connected()) {
    connectWiFi();
    Serial.print("Conectando ao broker MQTT...");
    if (mqtt.connect(DEVICE_ID, MQTT_USERNAME, MQTT_PASSWORD)) {
      Serial.println(" conectado");
    } else {
      Serial.printf(" falhou (estado %d); nova tentativa em 3 s\n", mqtt.state());
      delay(3000);
    }
  }
}

void publishReading() {
  const uint16_t soilRaw = readSoilRaw();
  const uint8_t soilPercent = soilMoisturePercent(soilRaw);
  const float temperature = dht.readTemperature();
  const float humidity = dht.readHumidity();

  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("Leitura DHT22 inválida; mensagem não publicada.");
    return;
  }

  char payload[256];
  snprintf(payload, sizeof(payload),
    "{\"deviceId\":\"%s\",\"messageNumber\":%lu,\"soilRaw\":%u,\"soilMoisturePct\":%u,\"airTemperatureC\":%.1f,\"airHumidityPct\":%.1f,\"uptimeMs\":%lu}",
    DEVICE_ID,
    static_cast<unsigned long>(++messageNumber),
    soilRaw,
    soilPercent,
    temperature,
    humidity,
    static_cast<unsigned long>(millis())
  );

  if (mqtt.publish(MQTT_TOPIC, payload)) {
    Serial.printf("MQTT publicado em %s: %s\n", MQTT_TOPIC, payload);
  } else {
    Serial.println("Falha ao publicar a leitura MQTT.");
  }
}
} // namespace

void setup() {
  Serial.begin(115200);
  delay(300);
  analogReadResolution(12);
  dht.begin();
  mqtt.setServer(MQTT_BROKER_HOST, MQTT_BROKER_PORT);
  mqtt.setKeepAlive(30);
  mqtt.setBufferSize(384);
  connectWiFi();
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) connectWiFi();
  if (!mqtt.connected()) connectMqtt();
  mqtt.loop();

  const uint32_t now = millis();
  if (now - lastSampleAt >= SAMPLE_INTERVAL_MS) {
    lastSampleAt = now;
    publishReading();
  }
  delay(5);
}
